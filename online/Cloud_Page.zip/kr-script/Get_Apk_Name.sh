#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上


rm -rf "$APK_Name_list"
am start -n com.gjzs.chongzhi.online/com.projectkr.shell.DialogActivity
