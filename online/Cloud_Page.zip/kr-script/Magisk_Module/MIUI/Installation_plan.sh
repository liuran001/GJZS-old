#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上


echo "Magisk|①使用Magisk（面具）挂载方案"
echo "mtz|②打包成.mtz主题文件格式"
