#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上


echo "0|默认"
echo "HuaJi|滑稽表情返回特效"
echo "SYHuaJi|受虐滑稽表情返回特效"
echo "XiaoKu|笑哭表情返回特效"
echo "XieYanXiao|斜眼笑表情返回特效"
echo "Hong|红色返回特效"
echo "Zi|紫色返回特效"
echo "TouMing|透明无特效"
