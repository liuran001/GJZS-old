#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上


. $Load Card_Brush_Bag "$@"
cp -f "$Download_File" "$File_Dir/$2.zip"
echo
echo "- 已下载到$File_Dir/$2.zip"
