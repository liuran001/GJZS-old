#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上


ip -br addr
echo -e "\n开始查看位置IP："
curl cip.cc
# ip.cip.cc
# myip.ipip.net
# ip.tool.lu
# ifconfig.me
# http://members.3322.org/dyndns/getip
