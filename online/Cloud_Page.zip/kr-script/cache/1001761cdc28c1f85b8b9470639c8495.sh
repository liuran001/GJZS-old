#Han.GJZS

[[ `wc -l 2>/dev/null < $Pages/Search_Results.xml` -gt 13 ]] && echo 1 || echo 0